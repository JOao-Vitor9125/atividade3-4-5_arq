export interface IOrderRepository {
  create(orderData: any): Promise<any>;
}

