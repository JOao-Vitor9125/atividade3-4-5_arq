import { IOrderRepository } from "./order_InterfaceRepo";
import { PrismaClient } from '@prisma/client';


const prisma = new PrismaClient();

export class PrismaOrderRepository implements IOrderRepository{
    async findProdById(id:number):Promise<any>{
        return await prisma.product.findUnique({ where: { id: id } });
    }
    async create(orderData: any): Promise<any>{
        return await prisma.order.create({
            data: {
                customer: orderData.data.customer,
                items: orderData.data.items,
                total: orderData.data.total,
                status: "confirmed"
            }
        });
    }
}