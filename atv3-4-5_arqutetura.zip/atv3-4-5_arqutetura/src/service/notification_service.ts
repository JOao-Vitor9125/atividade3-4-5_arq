import {IMailProvider} from "../mailer/mailer_interface";

export class NotificationService{
    constructor(private provider:IMailProvider){}

    async SendConfirmation(customer_mail:string, order_data:any, detalhes:any[]): Promise<string | undefined>{
        const subject = `Confirmação do Pedido #${order_data.id}`;

        const text= `Olá, seu pedido #${order_data.id} no valor de R$ ${order_data.total} foi confirmado.`

        const body = `
          <h1>Pedido Confirmado!</h1>
          <p>Olá, seu pedido <b>#${order_data.id}</b> foi processado com sucesso.</p>
          <p>Total: <strong>R$ ${order_data.total}</strong></p>
          <ul>
            ${detalhes.map(p => `<li>${p.name}</li>`).join('')}
          </ul>
        `;

        return await this.provider.send_mail(customer_mail, subject, text, body);

    }
}
