import logger from "../lib/logger";


export class OrderService{

    public validateCart(items:any[]){
        if (!items || items.length === 0) {
        logger.error('Tentativa de pedido sem itens');
        
      }
    }
}