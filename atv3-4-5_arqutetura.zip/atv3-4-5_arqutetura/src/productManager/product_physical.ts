import {IProduct} from "./product_interface";

export class PhysicalProduct implements IProduct{
    constructor(public id: number, public name: string, public price: number){}

    public calculateFreight(): number {
        return 10;
    }
}