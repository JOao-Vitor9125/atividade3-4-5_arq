import { IProduct } from './product_interface';
import { PhysicalProduct } from './product_physical';
import { DigitalProduct } from './product_digital';

export class ProductFactory{
    static create(data:any):IProduct{
        if(data.type === 'physical'){
            return new PhysicalProduct(data.id, data.name, data.price)
        
        }else if (data.type === 'digital') {
            return new DigitalProduct(data.id, data.name, data.price);
        }
        throw new Error('Unknown product type');
    }
}