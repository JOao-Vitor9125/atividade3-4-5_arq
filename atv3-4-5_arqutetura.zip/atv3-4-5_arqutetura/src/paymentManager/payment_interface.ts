export interface IPayment{
    process():void;
}
