import logger from "../lib/logger";
import { CreditCardPayment } from "./payment_credit";
import { PixPayment } from "./payment_pix";


export class PaymentProcessor{
    public process(metodo:string, detalhes:any):number{
        if(metodo === 'credit_card'){
            new CreditCardPayment(detalhes).process(); return 0;
        }
        
        if(metodo === 'pix'){
            new PixPayment(detalhes).process(); return 0;
        }
        if(metodo === 'debit_card'){
            logger.info('Processando débito...'); return 0;
        }
        return 1;
        
    }
}