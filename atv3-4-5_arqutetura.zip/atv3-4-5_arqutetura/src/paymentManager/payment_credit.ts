import {IPayment} from "./payment_interface";
import logger from "../lib/logger";

export class CreditCardPayment implements IPayment{
    constructor(private details:{cardNumber:string; cvv:string}){}
    public process():void{
        if(this.details.cardNumber)
        logger.info(`Processando cartão final ${this.details.cardNumber.slice(-4)}`);

        if (this.details.cvv === '000') throw new Error('Cartão recusado');
    }
}