import {IPayment} from "./payment_interface";
import logger from "../lib/logger";


export class PixPayment implements IPayment{
    constructor(chave:string){}

    public process():void{
        logger.info(`Aguardando confirmação do pix...... pix consfirmado`);
    }
    
}



