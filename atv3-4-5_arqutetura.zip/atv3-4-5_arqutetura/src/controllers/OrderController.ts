import {Request, Response} from 'express';
import logger from '../lib/logger';
import {PrismaOrderRepository} from '../repositories/order_PrismaRepo';
import {ProductFactory} from '../productManager/product_factory';
import {PaymentProcessor} from '../paymentManager/payment_processor';
import {NotificationService} from '../service/notification_service';
import {EtherealMailProvider} from '../mailer/mailer_provider';
import {OrderService} from '../service/order_service';

const validator = new OrderService();

const provedor = new EtherealMailProvider();
const notificator = new NotificationService(provedor);

const PrismaRepo = new PrismaOrderRepository();
const paymentProcessor = new PaymentProcessor();

// Lembram do God Class q falamos em aula? Este é um exemplo
export class OrderController {
  
  // Método Gigante: Violação de SRP
  async processOrder(req: Request, res: Response) {
    try {
      const { customer, items, paymentMethod, paymentDetails } = req.body;

      // 1. VALIDAÇÃO (Deveria estar em outro lugar)                      CHECK VV
      try{
        validator.validateCart(items);
      }catch(error:any){
        return res.status(400).json({ error: 'Carrinho vazio' });
      }

      // 2. CÁLCULO DE PREÇO E ESTOQUE (Regra de Negócio Misturada)            CHECK VV
      let totalAmount = 0;
      let productsDetails = [];

      for (const item of items) {
        const productData = await PrismaRepo.findProdById(item.productId);        
      
        if (!productData) {
          return res.status(400).json({ error: `Produto ${item.productId} não encontrado` });
        }

        const product = ProductFactory.create(productData);

        const itemTotal = product.price * item.quantity;
        const freight = product.calculateFreight();

        totalAmount+=itemTotal + freight;
      
        productsDetails.push({ ...product, quantity: item.quantity });
      }

      // 3. PROCESSAMENTO DE PAGAMENTO (Violação de OCP)
      // Se quisermos adicionar "Pix", temos que modificar essa classe.       CHECK VV
      if(paymentProcessor.process(paymentMethod, paymentDetails) === 0){
        console.log("ok");
      }
      else return res.status(400).json({ error: 'Método de pagamento não suportado' });
      

      // 4. PERSISTÊNCIA (Violação de SRP - Controller acessando Banco)           CHECK VV
      const order = await PrismaRepo.create({
        data: {
          customer: customer,
          items: JSON.stringify(productsDetails),
          total: totalAmount,
          status: "confirmed"
        }
      });

      // 5. NOTIFICAÇÃO (Violação de SRP - Efeitos colaterais no Controller)    CHECK VV

      const info = await notificator.SendConfirmation(customer, {id:order.id, total:totalAmount, status:'confirmado'}, productsDetails);

      logger.info(`Email enviado: ${info}`); 

      return res.json({ 
        message: 'Pedido processado com sucesso', 
        orderId: order.id,
        emailPreview: info 
      });

    } catch (error: any) {
      logger.error(`Erro ao processar pedido: ${error.message}`);
      return res.status(500).json({ error: 'Erro interno' });
    }
  }
}