import {IMailProvider} from "./mailer_interface";
import {getMailClient} from "../lib/mail";
import nodemailer from 'nodemailer';

export class EtherealMailProvider implements IMailProvider{
    async send_mail(to: any, subject: string, text:string, body: string): Promise<string | undefined>{
        const transporter = getMailClient();

        const info= await (await transporter).sendMail({
            from: `"DevStore" <noreply@devstore.com>`,
            to,
            subject,
            text,
            html:body,
        });
        
        const previewUrl = nodemailer.getTestMessageUrl(info);
        return previewUrl || undefined;
    }
    
}