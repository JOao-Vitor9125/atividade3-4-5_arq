export interface IMailProvider{
    send_mail(to:any , subject:string,text: string, body:string):Promise<string| undefined>;
}